package modelos.implementacion;

public class PedidoEncomienda extends Pedido {
    private double peso;
    private boolean embalajeValidado;

    public PedidoEncomienda(int idPedido, String direccionEntrega, double distanciaKm, double peso, boolean embalajeValidado) {
        super(idPedido, direccionEntrega, distanciaKm, "Encomienda");
        this.peso = peso;
        this.embalajeValidado = embalajeValidado;
    }

    public double getPeso() {
        return peso;
    }

    public boolean isEmbalajeValidado() {
        return embalajeValidado;
    }

    @Override
    public boolean validarEntrega() {
        return embalajeValidado && peso <= 20.0;
    }

    @Override
    public double calcularTiempoEntrega() {
        return  Math.round((20 + (1.5 * getDistanciaKm())));
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("Asignando repartidor...");
        String estado = (embalajeValidado && peso <= 20.0) ? "OK" : "NO OK";
        System.out.println("→ Validando peso y embalaje... " + estado);
        super.asignarRepartidor();
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("Asignando repartidor...");
        String estado = (embalajeValidado && peso <= 20.0) ? "OK" : "NO OK";
        System.out.println("→ Validando peso y embalaje... " + estado);
        super.asignarRepartidor(nombreRepartidor);
    }
}
